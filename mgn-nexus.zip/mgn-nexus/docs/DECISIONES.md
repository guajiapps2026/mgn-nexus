# Registro de decisiones — MGn NEXUS

## Aprobadas (10-oct-2026)
- Pila: React + Vite + TypeScript + Tailwind CSS; despliegue en Netlify.
- Datos: almacenamiento local con respaldo JSON primero; Supabase en una fase posterior. Sin servicios de pago sin autorización.
- Identidad: MGn NEXUS — Centro de Inteligencia Digital, estética dorado tecnológico.
- FITMOTION / FITNITION: nombre pendiente; un solo registro provisional, sin duplicados.

## Decisiones técnicas Fase 1
- Tailwind 3.4 (configuración estable con PostCSS). Versiones fijadas en package.json.
- React Router 6 con BrowserRouter; `_redirects` para que las rutas funcionen en Netlify.
- Módulos definidos en un solo archivo (`src/config/modules.ts`) para añadir o cambiar módulos sin tocar la navegación.
- Iconos: lucide-react (estilo uniforme).
- Tipografías Google Fonts (Sora + Inter) con respaldo del sistema si no cargan.
- Buscador visible pero desactivado hasta la Fase 2 (no hay datos que buscar).
- Zustand no se instala aún: se decidirá en la Fase 2 si hace falta.

## Estado
Hecho: estructura, navegación (escritorio, tableta, teléfono), identidad visual, panel de inicio vacío, marcadores de módulo, 404.
Falta: todo lo que maneje datos (Fase 2 en adelante).
