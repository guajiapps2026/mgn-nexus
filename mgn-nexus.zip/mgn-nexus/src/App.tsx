import { Route, Routes } from 'react-router-dom'
import AppLayout from './layout/AppLayout'
import Dashboard from './pages/Dashboard'
import ModulePage from './pages/ModulePage'
import NotFound from './pages/NotFound'
import { MODULES } from './config/modules'

export default function App() {
  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route index element={<Dashboard />} />
        {MODULES.map((m) => (
          <Route key={m.key} path={m.path} element={<ModulePage module={m} />} />
        ))}
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  )
}
