import { Outlet } from 'react-router-dom'
import Sidebar from '../components/Sidebar'
import MobileNav from '../components/MobileNav'
import Topbar from '../components/Topbar'

export default function AppLayout() {
  return (
    <div className="nexus-bg min-h-screen">
      <Sidebar />
      <div className="md:pl-[76px] lg:pl-64">
        <Topbar />
        <main className="mx-auto w-full max-w-6xl px-4 pb-28 pt-6 md:px-8 md:pb-12 md:pt-8">
          <Outlet />
        </main>
      </div>
      <MobileNav />
    </div>
  )
}
