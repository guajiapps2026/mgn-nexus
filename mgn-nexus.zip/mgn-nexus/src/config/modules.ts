import {
  Bot,
  FolderKanban,
  Package,
  Sparkles,
  TrendingUp,
  Cpu,
  Settings,
  LayoutDashboard,
  type LucideIcon,
} from 'lucide-react'

export type ModuleKey =
  | 'assistant'
  | 'projects'
  | 'products'
  | 'creator'
  | 'growth'
  | 'ai-tools'
  | 'settings'

export interface NexusModule {
  key: ModuleKey
  path: string
  label: string // nombre en la navegación
  title: string // nombre oficial
  icon: LucideIcon
  summary: string
  willInclude: string[]
  phase: number // fase en la que se construye
  phaseNote: string
}

export const HOME = { path: '/', label: 'Inicio', icon: LayoutDashboard }

export const MODULES: NexusModule[] = [
  {
    key: 'assistant',
    path: '/assistant',
    label: 'Assistant',
    title: 'NEXUS ASSISTANT',
    icon: Bot,
    summary: 'Asistente central: convierte ideas en planes y prepara instrucciones para otras IA.',
    willInclude: [
      'Recibir ideas en lenguaje natural y proponer el siguiente paso',
      'Convertir ideas en planes de trabajo',
      'Crear instrucciones (prompts) para otras inteligencias artificiales',
      'Consultar los proyectos y productos registrados',
      'Historial de decisiones con estados de acción verificables',
    ],
    phase: 6,
    phaseNote: 'Con IA real mediante API, solo con tu aprobación previa de costos.',
  },
  {
    key: 'projects',
    path: '/projects',
    label: 'Projects',
    title: 'NEXUS PROJECTS',
    icon: FolderKanban,
    summary: 'Proyectos con objetivo, etapa, tareas, recursos y bitácora de decisiones.',
    willInclude: [
      'Nombre, descripción, objetivo y etapa de desarrollo',
      'Tareas pendientes y completadas, con fecha y prioridad',
      'Archivos y recursos asociados',
      'Registro de avances, decisiones y próximos pasos',
    ],
    phase: 2,
    phaseNote: 'Se construye junto con Products, con datos locales y respaldo JSON.',
  },
  {
    key: 'products',
    path: '/products',
    label: 'Products',
    title: 'NEXUS PRODUCTS',
    icon: Package,
    summary: 'Catálogo central de productos digitales y su estado de publicación.',
    willInclude: [
      'Registrar productos, categoría y público objetivo',
      'Precio, plataforma y estado: idea, desarrollo, prueba, publicado, en promoción',
      'Vincular cada producto con su proyecto',
      'Crear, editar y eliminar; exportar e importar respaldo JSON',
    ],
    phase: 2,
    phaseNote: 'Será el primer módulo funcional con datos.',
  },
  {
    key: 'creator',
    path: '/creator',
    label: 'Creator',
    title: 'NEXUS CREATOR',
    icon: Sparkles,
    summary: 'Organiza la creación de libros, cartillas, miniaplicaciones y materiales bilingües.',
    willInclude: [
      'Libros digitales, cartillas y materiales educativos bilingües',
      'Miniaplicaciones y páginas de venta',
      'Prompts para herramientas de IA',
      'Guiones, imágenes, videos y otros recursos creativos',
    ],
    phase: 3,
    phaseNote: 'Organización y plantillas de prompts, con datos locales.',
  },
  {
    key: 'growth',
    path: '/growth',
    label: 'Growth',
    title: 'NEXUS GROWTH',
    icon: TrendingUp,
    summary: 'Marketing y ventas: ofertas, campañas, textos y embudos.',
    willInclude: [
      'Público objetivo y propuesta de valor',
      'Ofertas comerciales y planificación de campañas',
      'Textos publicitarios y contenidos para redes',
      'Resultados solo cuando existan datos verificables',
    ],
    phase: 4,
    phaseNote: 'Planificación y registro; sin publicar nada en plataformas externas.',
  },
  {
    key: 'ai-tools',
    path: '/ai-tools',
    label: 'AI Tools',
    title: 'NEXUS AI TOOLS',
    icon: Cpu,
    summary: 'Directorio de herramientas de IA con su estado real de integración.',
    willInclude: [
      'Nombre, función, uso recomendado y enlace',
      'Proyecto al que se vincula cada herramienta',
      'Estado de integración: Conectada / No conectada',
      'Instrucciones de uso',
    ],
    phase: 3,
    phaseNote: 'Ninguna herramienta se marcará como conectada sin integración funcional verificada.',
  },
  {
    key: 'settings',
    path: '/settings',
    label: 'Settings',
    title: 'NEXUS SETTINGS',
    icon: Settings,
    summary: 'Preferencias, gestión de datos y futuras integraciones.',
    willInclude: [
      'Exportar, importar y recuperar datos (respaldo JSON)',
      'Preferencias de la plataforma',
      'Estado de integraciones futuras',
    ],
    phase: 2,
    phaseNote: 'Empieza con la gestión de respaldo JSON.',
  },
]

// Acciones del asistente: etiquetas fijas definidas en el proyecto maestro
export const ACTION_STATES = [
  { key: 'idea', label: 'Idea propuesta', tone: 'text-sky-300 border-sky-400/30 bg-sky-400/10' },
  { key: 'plan', label: 'Plan preparado', tone: 'text-gold-light border-gold/40 bg-gold/10' },
  { key: 'done', label: 'Ejecutada en plataforma', tone: 'text-emerald-300 border-emerald-400/30 bg-emerald-400/10' },
  { key: 'pending', label: 'Pendiente de autorización', tone: 'text-amber-300 border-amber-400/30 bg-amber-400/10' },
  { key: 'verified', label: 'Externa completada y verificada', tone: 'text-teal-200 border-teal-300/30 bg-teal-300/10' },
] as const

export const PHASES = [
  { n: 1, label: 'Estructura base, navegación e identidad visual', status: 'current' },
  { n: 2, label: 'Products + Projects con datos locales y respaldo JSON', status: 'next' },
  { n: 3, label: 'AI Tools y Creator', status: 'later' },
  { n: 4, label: 'Growth', status: 'later' },
  { n: 5, label: 'Supabase: cuentas y datos en la nube', status: 'later' },
  { n: 6, label: 'Assistant con IA real (con aprobación de costos)', status: 'later' },
  { n: 7, label: 'Integraciones externas verificadas', status: 'later' },
] as const
