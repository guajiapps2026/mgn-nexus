import { NavLink } from 'react-router-dom'
import Logo from './Logo'
import { HOME, MODULES } from '../config/modules'

const linkBase =
  'group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors border border-transparent'

export default function Sidebar() {
  const items = [HOME, ...MODULES]
  return (
    <aside className="fixed inset-y-0 left-0 z-30 hidden w-[76px] flex-col border-r border-gold/15 bg-night-900/90 backdrop-blur md:flex lg:w-64">
      <div className="flex h-20 items-center justify-center border-b border-gold/10 px-4 lg:justify-start">
        <div className="hidden lg:block">
          <Logo />
        </div>
        <div className="lg:hidden">
          <Logo size="sm" showDescriptor={false} />
        </div>
      </div>

      <nav className="flex-1 space-y-1 overflow-y-auto p-3" aria-label="Módulos">
        {items.map(({ path, label, icon: Icon }) => (
          <NavLink
            key={path}
            to={path}
            end={path === '/'}
            title={label}
            className={({ isActive }) =>
              `${linkBase} justify-center lg:justify-start ${
                isActive
                  ? 'border-gold/30 bg-gold/10 text-gold-light shadow-[inset_3px_0_0_0_#D8B66B]'
                  : 'text-mist/65 hover:border-electric/30 hover:bg-electric/10 hover:text-mist'
              }`
            }
          >
            <Icon size={19} strokeWidth={1.75} />
            <span className="hidden lg:inline">{label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="hidden border-t border-gold/10 p-4 text-[11px] leading-snug text-mist/40 lg:block">
        Fase 1 · Estructura base
        <br />
        Datos: ninguno todavía
      </div>
    </aside>
  )
}
