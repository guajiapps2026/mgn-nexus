interface Props {
  size?: 'sm' | 'lg'
  showDescriptor?: boolean
}

export default function Logo({ size = 'lg', showDescriptor = true }: Props) {
  const big = size === 'lg'
  return (
    <div className="flex flex-col leading-none select-none" aria-label="MGn NEXUS — Centro de Inteligencia Digital">
      <div className="flex items-baseline gap-2">
        <span
          className={`gold-text font-display font-bold tracking-tight ${big ? 'text-4xl' : 'text-2xl'}`}
          style={{ filter: 'drop-shadow(0 0 10px rgba(216,182,107,0.25))' }}
        >
          MGn
        </span>
        <span
          className={`font-display font-semibold text-mist/80 ${big ? 'text-sm tracking-[0.42em]' : 'text-[10px] tracking-[0.36em]'}`}
        >
          NEXUS
        </span>
      </div>
      {showDescriptor && (
        <span className="mt-1.5 whitespace-nowrap text-[9px] uppercase tracking-[0.16em] text-mist/45">
          Centro de Inteligencia Digital
        </span>
      )}
    </div>
  )
}
