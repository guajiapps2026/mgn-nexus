import { useEffect, useState } from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import { Ellipsis, X } from 'lucide-react'
import { HOME, MODULES } from '../config/modules'

const primary = [
  HOME,
  ...['projects', 'products', 'assistant'].map((k) => MODULES.find((m) => m.key === k)!),
]
const more = MODULES.filter((m) => !['projects', 'products', 'assistant'].includes(m.key))

export default function MobileNav() {
  const [open, setOpen] = useState(false)
  const { pathname } = useLocation()

  useEffect(() => setOpen(false), [pathname])

  const moreActive = more.some((m) => pathname.startsWith(m.path))

  return (
    <>
      {open && (
        <div className="fixed inset-0 z-40 md:hidden" role="dialog" aria-label="Más módulos">
          <button
            className="absolute inset-0 bg-black/60"
            aria-label="Cerrar"
            onClick={() => setOpen(false)}
          />
          <div className="absolute inset-x-0 bottom-[68px] mx-3 animate-rise rounded-2xl border border-gold/25 bg-night-800 p-3 shadow-card">
            <div className="mb-2 flex items-center justify-between px-2">
              <span className="text-xs uppercase tracking-widest text-mist/50">Más módulos</span>
              <button onClick={() => setOpen(false)} aria-label="Cerrar" className="text-mist/60">
                <X size={18} />
              </button>
            </div>
            {more.map(({ path, label, icon: Icon }) => (
              <NavLink
                key={path}
                to={path}
                className={({ isActive }) =>
                  `flex items-center gap-3 rounded-xl px-3 py-3 text-sm ${
                    isActive ? 'bg-gold/10 text-gold-light' : 'text-mist/80'
                  }`
                }
              >
                <Icon size={19} strokeWidth={1.75} />
                {label}
              </NavLink>
            ))}
          </div>
        </div>
      )}

      <nav
        className="fixed inset-x-0 bottom-0 z-50 grid h-[68px] grid-cols-5 border-t border-gold/20 bg-night-900/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden"
        aria-label="Navegación principal"
      >
        {primary.map(({ path, label, icon: Icon }) => (
          <NavLink
            key={path}
            to={path}
            end={path === '/'}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center gap-1 text-[11px] ${
                isActive ? 'text-gold-light' : 'text-mist/55'
              }`
            }
          >
            <Icon size={20} strokeWidth={1.75} />
            {label}
          </NavLink>
        ))}
        <button
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          className={`flex flex-col items-center justify-center gap-1 text-[11px] ${
            moreActive || open ? 'text-gold-light' : 'text-mist/55'
          }`}
        >
          <Ellipsis size={20} strokeWidth={1.75} />
          Más
        </button>
      </nav>
    </>
  )
}
