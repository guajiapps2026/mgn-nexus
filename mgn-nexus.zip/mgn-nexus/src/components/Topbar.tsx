import { Link } from 'react-router-dom'
import { Bot, Search } from 'lucide-react'
import Logo from './Logo'

export default function Topbar() {
  return (
    <header className="sticky top-0 z-20 flex h-16 items-center gap-3 border-b border-gold/10 bg-night-800/80 px-4 backdrop-blur md:h-20 md:px-8">
      <div className="md:hidden">
        <Logo size="sm" showDescriptor={false} />
      </div>

      {/* El buscador se activa en la Fase 2, cuando existan datos que buscar */}
      <div className="ml-auto flex w-full max-w-md items-center gap-2 md:ml-0">
        <label className="relative hidden flex-1 md:block">
          <span className="sr-only">Buscar (disponible en la Fase 2)</span>
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-mist/35" />
          <input
            disabled
            placeholder="Buscar — disponible en la Fase 2"
            className="w-full cursor-not-allowed rounded-xl border border-gold/10 bg-night-950/60 py-2.5 pl-9 pr-3 text-sm text-mist placeholder:text-mist/35"
          />
        </label>
      </div>

      <Link
        to="/assistant"
        className="ml-auto inline-flex items-center gap-2 rounded-xl border border-gold/35 bg-gold/10 px-3.5 py-2 text-sm font-medium text-gold-light transition hover:border-electric/50 hover:shadow-glow md:ml-0"
      >
        <Bot size={17} strokeWidth={1.75} />
        <span className="hidden sm:inline">NEXUS Assistant</span>
      </Link>
    </header>
  )
}
