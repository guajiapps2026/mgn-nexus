import { Link } from 'react-router-dom'
import { ArrowRight, CircleCheck, CircleDashed, Circle } from 'lucide-react'
import { ACTION_STATES, MODULES, PHASES } from '../config/modules'

const PRODUCT_STATES = ['Idea', 'Desarrollo', 'Prueba', 'Publicado', 'En promoción']

export default function Dashboard() {
  return (
    <div className="space-y-8">
      <section className="animate-rise">
        <p className="text-xs uppercase tracking-[0.25em] text-mist/45">Centro de Inteligencia Digital</p>
        <h1 className="mt-2 font-display text-3xl font-semibold md:text-4xl">
          Bienvenido a <span className="gold-text">MGn NEXUS</span>
        </h1>
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-mist/65">
          Esta es la estructura base (Fase 1). Todavía no hay datos: los módulos con información real
          se activan desde la Fase 2. Nada aquí está simulado.
        </p>
      </section>

      {/* Resumen con estados vacíos honestos */}
      <section className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4" aria-label="Resumen">
        {[
          { label: 'Proyectos activos', note: 'Se activa en la Fase 2' },
          { label: 'Productos registrados', note: 'Se activa en la Fase 2' },
          { label: 'Tareas próximas', note: 'Se activa en la Fase 2' },
          { label: 'Herramientas de IA conectadas', note: 'Ninguna conectada' },
        ].map((s, i) => (
          <div
            key={s.label}
            className="nexus-card nexus-card-hover animate-rise p-5"
            style={{ animationDelay: `${i * 60}ms` }}
          >
            <p className="text-xs text-mist/55">{s.label}</p>
            <p className="gold-text mt-2 font-display text-4xl font-bold">0</p>
            <p className="mt-2 text-[11px] text-mist/40">{s.note}</p>
          </div>
        ))}
      </section>

      <div className="grid items-start gap-6 lg:grid-cols-5">
        <section className="nexus-card animate-rise p-5 lg:col-span-3" aria-label="Productos por estado">
          <h2 className="font-display text-lg font-semibold">Productos por estado</h2>
          <p className="mt-1 text-xs text-mist/50">Sin productos registrados todavía.</p>
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-5">
            {PRODUCT_STATES.map((s) => (
              <div key={s} className="rounded-xl border border-gold/10 bg-night-950/50 p-3 text-center">
                <p className="font-display text-xl font-semibold text-mist/80">0</p>
                <p className="mt-1 text-[11px] text-mist/50">{s}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="nexus-card animate-rise p-5 lg:col-span-2" aria-label="Ruta de desarrollo">
          <h2 className="font-display text-lg font-semibold">Ruta de desarrollo</h2>
          <ol className="mt-4 space-y-3">
            {PHASES.map((p) => (
              <li key={p.n} className="flex items-start gap-3 text-sm">
                {p.status === 'current' ? (
                  <CircleDashed size={18} className="mt-0.5 shrink-0 text-gold" />
                ) : p.status === 'next' ? (
                  <Circle size={18} className="mt-0.5 shrink-0 text-electric" />
                ) : (
                  <Circle size={18} className="mt-0.5 shrink-0 text-mist/25" />
                )}
                <span className={p.status === 'later' ? 'text-mist/45' : 'text-mist/85'}>
                  <span className="text-mist/40">Fase {p.n} · </span>
                  {p.label}
                  {p.status === 'current' && <span className="ml-2 text-[11px] text-gold">en curso</span>}
                </span>
              </li>
            ))}
          </ol>
        </section>
      </div>

      <section aria-label="Módulos">
        <h2 className="mb-4 font-display text-lg font-semibold">Módulos</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {MODULES.map(({ key, path, title, icon: Icon, summary, phase }, i) => (
            <Link
              key={key}
              to={path}
              className="nexus-card nexus-card-hover group animate-rise p-5"
              style={{ animationDelay: `${i * 50}ms` }}
            >
              <div className="flex items-center justify-between">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-gold/25 bg-gold/10 text-gold">
                  <Icon size={19} strokeWidth={1.75} />
                </span>
                <span className="rounded-full border border-mist/10 px-2 py-0.5 text-[10px] text-mist/45">
                  Fase {phase}
                </span>
              </div>
              <h3 className="mt-4 font-display text-sm font-semibold tracking-wide">{title}</h3>
              <p className="mt-1.5 text-xs leading-relaxed text-mist/55">{summary}</p>
              <span className="mt-4 inline-flex items-center gap-1 text-xs text-gold/80 transition group-hover:gap-2">
                Ver módulo <ArrowRight size={13} />
              </span>
            </Link>
          ))}
        </div>
      </section>

      <section className="nexus-card animate-rise p-5" aria-label="Estados de acción del asistente">
        <h2 className="font-display text-lg font-semibold">Estados de acción del asistente</h2>
        <p className="mt-1 text-xs text-mist/50">
          Etiquetas fijas para distinguir siempre lo propuesto de lo realmente ejecutado.
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          {ACTION_STATES.map((s) => (
            <span key={s.key} className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs ${s.tone}`}>
              <CircleCheck size={13} />
              {s.label}
            </span>
          ))}
        </div>
      </section>
    </div>
  )
}
