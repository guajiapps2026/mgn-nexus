import { Link } from 'react-router-dom'
import { Check, Hammer } from 'lucide-react'
import type { NexusModule } from '../config/modules'

export default function ModulePage({ module: m }: { module: NexusModule }) {
  const Icon = m.icon
  return (
    <div className="animate-rise space-y-6">
      <header className="flex items-start gap-4">
        <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-gold/30 bg-gold/10 text-gold">
          <Icon size={22} strokeWidth={1.75} />
        </span>
        <div>
          <h1 className="gold-text font-display text-2xl font-semibold md:text-3xl">{m.title}</h1>
          <p className="mt-1.5 max-w-2xl text-sm text-mist/65">{m.summary}</p>
        </div>
      </header>

      <div className="nexus-card flex items-start gap-3 border-amber-300/25 p-4">
        <Hammer size={18} className="mt-0.5 shrink-0 text-amber-300" />
        <div className="text-sm">
          <p className="font-medium text-amber-200">Módulo aún no implementado</p>
          <p className="mt-1 text-mist/60">
            Se construye en la <strong className="text-mist/85">Fase {m.phase}</strong>. {m.phaseNote}
          </p>
        </div>
      </div>

      <section className="nexus-card p-5">
        <h2 className="font-display text-base font-semibold">Qué incluirá</h2>
        <ul className="mt-3 space-y-2.5">
          {m.willInclude.map((t) => (
            <li key={t} className="flex items-start gap-2.5 text-sm text-mist/75">
              <Check size={16} className="mt-0.5 shrink-0 text-gold" />
              {t}
            </li>
          ))}
        </ul>
      </section>

      <Link to="/" className="inline-block text-sm text-electric hover:underline">
        ← Volver al inicio
      </Link>
    </div>
  )
}
