import { Link } from 'react-router-dom'

export default function NotFound() {
  return (
    <div className="py-20 text-center">
      <p className="gold-text font-display text-6xl font-bold">404</p>
      <p className="mt-3 text-mist/60">Esta ruta no existe en MGn NEXUS.</p>
      <Link to="/" className="mt-6 inline-block text-electric hover:underline">
        Ir al inicio
      </Link>
    </div>
  )
}
